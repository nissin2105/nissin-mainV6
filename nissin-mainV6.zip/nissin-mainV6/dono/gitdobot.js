const gitdobot = (prefix) => {
return `
╔┅═┅══⟮ 🔥 ⟯══┅═┅═᳀
║ EM BREVE
╠┅═┅══⟮ 👾 ⟯══┅═┅═᳀
║  「 ${NomeDoBot} 」
╚┅═┅══⟮ ☔ ⟯══┅═┅═᳀
`
}

exports.gitdobot = gitdobot
