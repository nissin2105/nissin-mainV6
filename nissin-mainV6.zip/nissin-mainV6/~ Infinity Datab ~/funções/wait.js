const fs = require('fs')

var MsgsDeEspera = [
"👨🏿‍🦳 Espera Cabaço",
"🧓🏿 Calmae Mano To Quase Terminando",
"Espera Caralho Sou o Flash n",
"♻️ Espera Porra",
"🤨🧐",
"🌐 Iae Meu Principe, Ja to Enviando aguarde!",
"❇️ Daqui 1 Ano Termino Voce Que Morra",
"📍 Estou Terminando! Por Enquanto Tome Um Cafe",
"📱Sai Desse Celular Kralho Se Fica o Dia Todo ai KKKKK",
"ta Mais e o cara que falou corre cadeirante KKKKKKKKKKKKKKKKKK",
"Olha o Carro Da Rua Passando No Seu Ovo KKKKKK Ja Estou Enviando Espere.",
"Quem Alcança Sempre Espera KKKKKKKKKKK",
"enviando já!"
]

module.exports = {
MsgsDeEspera
}